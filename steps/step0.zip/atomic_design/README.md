# Atomic Design

A practical example of how to apply atomic design in Flutter.

## Links
- [Read more about atomic design](https://atomicdesign.bradfrost.com/chapter-2/)

## Credits/Material
- [Logistics Website Figma Template](https://www.freefigmatemplates.com/gallery/logistics-website-template) by [VictorFlow](https://www.figma.com/@victorflow)
- [Rubik font](https://fonts.google.com/specimen/Rubik)
- [Krub font](https://fonts.google.com/specimen/Krub)
